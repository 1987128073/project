var config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: "http://http-proxy-t1.dobel.cn",
        port: parseInt(9180)
      },
      bypassList: ["dobel.cn"]
    }
  };
 
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
 
function callbackFn(details) {
    return {
        authCredentials: {
            username: "ATLANDG4EGPK5S0",
            password: "LKHN5uFx"
        }
    };
}
 
chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        {urls: ["<all_urls>"]},
        ['blocking']
);
